!function(e){var t={};function n(r){if(t[r])return t[r].exports;var p=t[r]={i:r,l:!1,exports:{}};return e[r].call(p.exports,p,p.exports,n),p.l=!0,p.exports}n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var p in e)n.d(r,p,function(t){return e[t]}.bind(null,p));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=2)}({"./scripts/popup/index.ts":
/*!********************************!*\
  !*** ./scripts/popup/index.ts ***!
  \********************************/
/*! no static exports found */function(module,exports){eval("//let p = new Popup();\n\n\n//# sourceURL=webpack:///./scripts/popup/index.ts?")},"./styles/popup/index.scss":
/*!*********************************!*\
  !*** ./styles/popup/index.scss ***!
  \*********************************/
/*! no static exports found */function(module,exports,__webpack_require__){eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./styles/popup/index.scss?")},2:
/*!****************************************************************!*\
  !*** multi ./scripts/popup/index.ts ./styles/popup/index.scss ***!
  \****************************************************************/
/*! no static exports found */function(module,exports,__webpack_require__){eval('__webpack_require__(/*! ./scripts/popup/index.ts */"./scripts/popup/index.ts");\nmodule.exports = __webpack_require__(/*! ./styles/popup/index.scss */"./styles/popup/index.scss");\n\n\n//# sourceURL=webpack:///multi_./scripts/popup/index.ts_./styles/popup/index.scss?')}});