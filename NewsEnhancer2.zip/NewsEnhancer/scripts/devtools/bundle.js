!function(e){var t={};function n(o){if(t[o])return t[o].exports;var s=t[o]={i:o,l:!1,exports:{}};return e[o].call(s.exports,s,s.exports,n),s.l=!0,s.exports}n.m=e,n.c=t,n.d=function(e,t,o){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:o})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var o=Object.create(null);if(n.r(o),Object.defineProperty(o,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var s in e)n.d(o,s,function(t){return e[t]}.bind(null,s));return o},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=3)}({"./scripts/devtools/index.ts":
/*!***********************************!*\
  !*** ./scripts/devtools/index.ts ***!
  \***********************************/
/*! no static exports found */function(module,exports){eval('chrome.devtools.panels.create("Nyhets inspeksjon", "icons/icon.jpg", "html/panel.html", function (panel) {\n    // Here we instantiate communication with the background script via a long lived connection\n});\n\n\n//# sourceURL=webpack:///./scripts/devtools/index.ts?')},"./styles/devtools/index.scss":
/*!************************************!*\
  !*** ./styles/devtools/index.scss ***!
  \************************************/
/*! no static exports found */function(module,exports,__webpack_require__){eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./styles/devtools/index.scss?")},3:
/*!**********************************************************************!*\
  !*** multi ./scripts/devtools/index.ts ./styles/devtools/index.scss ***!
  \**********************************************************************/
/*! no static exports found */function(module,exports,__webpack_require__){eval('__webpack_require__(/*! ./scripts/devtools/index.ts */"./scripts/devtools/index.ts");\nmodule.exports = __webpack_require__(/*! ./styles/devtools/index.scss */"./styles/devtools/index.scss");\n\n\n//# sourceURL=webpack:///multi_./scripts/devtools/index.ts_./styles/devtools/index.scss?')}});